package com.example.physiohut;

public class Doctor {

    private String name;
    private String address;
    private String AFM;

    public Doctor(String name, String address, String AFM) {
        this.name = name;
        this.address = address;
        this.AFM = AFM;
    }
}
